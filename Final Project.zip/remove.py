import os
import pandas as pd

train_df = pd.read_csv("train_filter.txt", delimiter=" ", header=None)
test_df = pd.read_csv("test_filter.txt", delimiter=" ", header=None)

all_files = set(list(train_df[0].values) + list(test_df[0].values))

for filename in os.listdir("coco_synthetic"):
    if filename not in all_files:
        os.remove("coco_synthetic/" + filename)
        print(filename + "removed")

for filename in os.listdir("train2014"):
    if filename not in all_files:
        os.remove("train2014/" + filename)
        print(filename + "removed")
